# rock-paper-scissors
This program creates bots that play RPS.
